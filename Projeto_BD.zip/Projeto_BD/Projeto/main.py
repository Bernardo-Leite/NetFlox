import menu

menu.menu_inicial()